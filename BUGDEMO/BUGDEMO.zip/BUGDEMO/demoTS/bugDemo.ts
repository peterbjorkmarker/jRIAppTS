﻿/// <reference path="jriapp.d.ts"/>
export class DbSets extends RIAPP.MOD.db.DbSets {
    constructor(dbContext: DbContext) {
        super(dbContext);
    }
}

export class DbContext extends RIAPP.MOD.db.DbContext {
}

var db = new DbContext();
//for to see a bug remove ; after dbSets and try to add a dot - you will see a drop down list with private properties included
//but to notice after db (which also have private members drop down list does not include private members, it is only if you have a path like object1.object2. )
var bug = db.dbSets;
//bug. does not show private members
//db.dbSets.  show them!