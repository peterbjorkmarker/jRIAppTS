var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
define(["require", "exports"], function (require, exports) {
    /// <reference path="jriapp.d.ts"/>
    var DbSets = (function (_super) {
        __extends(DbSets, _super);
        function DbSets(dbContext) {
            _super.call(this, dbContext);
        }
        return DbSets;
    })(RIAPP.MOD.db.DbSets);
    exports.DbSets = DbSets;
    var DbContext = (function (_super) {
        __extends(DbContext, _super);
        function DbContext() {
            _super.apply(this, arguments);
        }
        return DbContext;
    })(RIAPP.MOD.db.DbContext);
    exports.DbContext = DbContext;
    var db = new DbContext();
    //for to see a bug remove ; after dbSets and try to add a dot - you will see a drop down list with private properties included
    //but to notice after db (which also have private members drop down list does not include private members, it is only if you have a path like object1.object2. )
    var bug = db.dbSets;
});
//# sourceMappingURL=bugDemo.js.map